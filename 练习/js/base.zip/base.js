




$(document).ready(function(){
    //
    //$(".list_1").click(
    //    function(){
    //        $(this).next(".list_2").toggle()
    //    }
    //);
    $(".list_1").click(
        function() {



            $(this).next(".list_2").toggle();
            var iconname=$(this).attr("iconname");
            var display = $(this).next(".list_2").eq(0).css("display");
            if (display=="none") {
                $(this).children("img").eq(0).attr("src", "images/"+iconname+".png");
                $(this).children("img").eq(1).attr("src", "images/left.png");
                $(this).css("backgroundColor", "#2f4050");

                $(this).children(".show").css("display","none");
                $(this).children("p").css("color","#a2a9bb");
                $(this).removeClass("played");

            } else {
                if($(".played").size()!=0)
                {
                    menuclose();
                    $(".played").removeClass("played");
                }

                $(this).css("backgroundColor","#1f2d3a") ;
                $(this).children("img").eq(0).attr("src", "images/"+iconname+"_1.png");
                $(this).children("img").eq(1).attr("src", "images/down_2.png");
                $(this).css("backgroundColor", "#1f2d3a");

                $(this).children(".show").css("display","block");
                $(this).children("p").css("color","#3197fc");
                $(this).addClass("played");
            }
            $(this).children("p").eq(0).attr("pre",$(this).children("p").eq(0).css("color"));
            $(this).children("img").eq(0).attr("pre",$(this).children("img").eq(0).attr("src")) ;
            $(this).children("img").eq(1).attr("pre",$(this).children("img").eq(1).attr("src")) ;
        }
    );
    $(".list_1").mouseenter(
        function(){
            $(this).css("background","#3197fc");

            var iconname=$(this).attr("iconname");
            //   $(this).children("p").addClass("list_1_p_1");
            $(this).children("img").eq(0).attr("pre",$(this).children("img").eq(0).attr("src")) ;

            $(this).children("p").eq(0).attr("pre",$(this).children("p").eq(0).css("color")) ;
            $(this).children("img").eq(0).attr("src","images/"+iconname+"_0.png");
            $(this).children("p").eq(0).css("color","white");


            var display = $(this).next(".list_2").eq(0).css("display");
            if (display!="none") {

                $(this).children("img").eq(1).attr("src","images/down_1.png");
            }
            else{
                $(this).children("img").eq(1).attr("pre",$(this).children("img").eq(1).attr("src")) ;

                $(this).children("img").eq(1).attr("src","images/left_1.png");

            }

        }
    )
    $(".list_1").mouseleave(
        function(){
            //$(this).children("p").removeClass("list_1_p_1");
            $(this).children("img").eq(0).attr("src",$(this).children("img").eq(0).attr("pre"));

            $(this).children("p").eq(0).css("color",$(this).children("p").eq(0).attr("pre"));
            $(this).css("background","#2f4050");

            var display = $(this).next(".list_2").eq(0).css("display");
            if (display!="none") {
                $(this).css("backgroundColor","#1f2d3a") ;
            }else{

            }  $(this).children("img").eq(1).attr("src",$(this).children("img").eq(1).attr("pre"));
        }
    )



    $(".list_3").click(
        function(){
            //alert($(this).children("p").html())
            $("#anav ul").append("<li onclick='clickfuntion(this)'><h4>111</h4><div class='sign'></div><div class='noshow'></div></li>")
        }
    )

    $(".list").click(
        function(){
            $(this).children(".min_show").css("display","block")
        }
    )
    $(".button").click(
        function(){
            var display =$(".base_left")[0].style.display == "block"?false:true;
            if (display) {
                $(".base_left").show().addClass("active_left");
                $(".min_left").hide().removeClass("active_left");
                $(".base_right").css({"width":$(window).width() - 160,"left":160}) ;
            }

            else{
                $(".base_left").hide().removeClass("active_left");
                $(".min_left").show().addClass("active_left");
                $(".base_right").css({"width":$(window).width() - 87,"left": 87}) ;
            }
        }
    )




    $(".list_2 li").mouseenter(
        function(){
            $(this).children(".list_3").css("display","block");
        }
    ).mouseleave(
        function(){
            $(this).children(".list_3").css("display","none")
        }
    )









});


/****************************************************************************************/

//alert($("div[name='left']").width())
$(window).resize(function () { //当浏览器大小变化时

    var offset = $(".active_left")[0].offsetWidth;
    var width=$(this).width()-offset;
    if(width<=820)
        width=820;
    $(".base_right").width(width);
})





function clickfuntion(obj)
{

    $(obj).children(".sign").css("display","block");
    $(obj).children("h4").addClass("h4_sign")
    $(obj).siblings().children(".sign").css("display","none");
    $(obj).siblings().children("h4").removeClass("h4_sign")
}
//
$("#anav ul li").click(
    function(){
        //alert($(this).html())
        $(this).children(".sign").css("display","block");
        $(this).children("h4").addClass("h4_sign")
        $(this).siblings().children(".sign").css("display","none");
        $(this).siblings().children("h4").removeClass("h4_sign")
    }
)


function menuclose()
{
    var obj=$(".played");
    $(obj).next(".list_2").css("display","none");
    var iconname=$(obj).attr("iconname");
    $(obj).children("img").eq(0).attr("src", "images/"+iconname+".png");
    $(obj).children("img").eq(1).attr("src", "images/left.png");
    $(obj).css("backgroundColor", "#2f4050");

    $(obj).children(".show").css("display","none");
    $(obj).children("p").css("color","#a2a9bb");
    $(obj).removeClass("played");
}







